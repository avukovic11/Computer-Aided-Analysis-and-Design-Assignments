This code consists of:
1. matrix.py which contains the matrix and operations with it
2. main.py which imports the class Matrix and runs all 10 of the tasks from the laboratory exercise.
Instructions to run main.py:
1. open terminal
1. position yourself in the directory of file main.py
2. run command 'python main.py'